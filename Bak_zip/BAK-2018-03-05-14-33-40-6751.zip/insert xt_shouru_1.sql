-- 表的数据: xt_shouru --
INSERT INTO `xt_shouru` VALUES ('3739','3818','012','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3738','3817','011','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3737','3816','010','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3736','3815','009','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3735','3814','008','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3734','3813','007','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3733','3812','006','800.00','1520133245','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3732','3811','005','800.00','1520133244','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3731','3810','004','800.00','1520131529','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3730','3809','003','800.00','1520131528','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3729','3808','002','800.00','1520131528','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3728','3807','001','800.00','1520131528','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3727','3806','wl','40000.00','1520131077','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3726','3805','cuiz','40000.00','1520131077','新会员加入','0');-- <fen> --
INSERT INTO `xt_shouru` VALUES ('3740','3819','slj','800.00','1520230482','新会员加入','0');-- <fen> --
