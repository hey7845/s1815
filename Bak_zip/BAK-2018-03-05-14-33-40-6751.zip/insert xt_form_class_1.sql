-- 表的数据: xt_form_class --
INSERT INTO `xt_form_class` VALUES ('1','新闻公告','0');-- <fen> --
