-- 表的数据: xt_address --
INSERT INTO `xt_address` VALUES ('1','1','XX','广西北海银海区桂电大学','14788888888','1');-- <fen> --
