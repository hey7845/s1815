-- 表的数据: xt_times --
INSERT INTO `xt_times` VALUES ('371','1520697599','1262275200','0','0','0','0');-- <fen> --
