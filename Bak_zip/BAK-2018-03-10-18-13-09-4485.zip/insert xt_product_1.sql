-- 表的数据: xt_product --
INSERT INTO `xt_product` VALUES ('22','2','酒','1','','','150.00','800.00','0.00','1472605945','<p>惊爆商品</p>','/s827/Public/Uploads/image/2016083109125599.jpg','0','','1');-- <fen> --
