-- 表的数据: xt_cptype --
INSERT INTO `xt_cptype` VALUES ('1','产品1','0','0','0','0');-- <fen> --
INSERT INTO `xt_cptype` VALUES ('2','产品2','0','0','0','0');-- <fen> --
INSERT INTO `xt_cptype` VALUES ('3','产品3','0','0','0','0');-- <fen> --
