-- 表的数据: xt_zhuanj --
INSERT INTO `xt_zhuanj` VALUES ('16946','3889','3888','sunshujing','lihongqi','800.00','1520674288',NULL,'1','0','0');-- <fen> --
INSERT INTO `xt_zhuanj` VALUES ('16947','3889','3888','sunshujing','lihongqi','800.00','1520674369',NULL,'4','0','0');-- <fen> --
